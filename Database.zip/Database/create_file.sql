CREATE TABLE SIZE_X(
    model_id varchar(18) primary key,
    model_name varchar(30), 
    model_year int
);

CREATE TABLE CARD_(
    card_num bigint primary key, 
    exp_date DATE
);

CREATE TABLE CAR(
   lisence_plate varchar(18) primary key,
   purchase_date DATE, 
   curr_condition int, 
   model_id varchar(18), FOREIGN KEY(model_id) REFERENCES size_x
);

CREATE TABLE PASSENGER(
    passenger_id int primary key, 
    fname varchar(30), 
    lname varchar(30), 
    phone_num bigint, 
    card_num bigint, 
    FOREIGN KEY(card_num) REFERENCES card_
);

CREATE TABLE driver(
    driver_id varchar(50) primary key, 
    fname varchar(100), 
    lname varchar (100), 
    phone_num bigint, 
    working_hours int, 
    avg_ratings int, 
    num_ratings int, 
    lisence_plate varchar(18), FOREIGN KEY(lisence_plate) REFERENCES car
);

CREATE TABLE COMPLETERIDE(
    ride_id int primary key, 
    pickup_location varchar(100), 
    destination varchar(100), 
    surge float, 
    total_distance float, 
    total_time TIMESTAMP,
    price float, 
    passenger_id int, 
    driver_id varchar(50),
    FOREIGN KEY(passenger_id) REFERENCES passenger
);

CREATE TABLE currride(
    ride_id int PRIMARY KEY, 
    pickup_location varchar(100),
    destination varchar(100), 
    surge float, 
    elapsed_distance float, 
    elapsed_time timestamptz, 
    passenger_id int, 
    driver_id varchar(50), 
    FOREIGN KEY(passenger_id) REFERENCES passenger
);

CREATE TABLE requests(
    request_id int primary key, 
    pickup_location varchar(100),
    destination varchar(100), 
    request_time timestamptz,
    surge float, 
    passenger_id int,
    FOREIGN KEY(passenger_id) REFERENCES passenger
);


